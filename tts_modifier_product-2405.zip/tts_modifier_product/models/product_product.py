# -*- coding: utf-8 -*-

from odoo import models, fields, api
import StringIO
import xlsxwriter

class product_product_ihr(models.Model):
    _inherit = 'product.product'

    sp_ban_chua_giao = fields.Integer(compute='_compute_product')
    sp_da_bao_gia = fields.Integer(compute='_compute_product')
    sp_co_the_ban = fields.Integer(compute='_compute_product')

    @api.depends('qty_available', 'virtual_available')
    def _compute_product(self):
        for rec in self:
            rec.sp_ban_chua_giao = rec.qty_available - rec.virtual_available
            line_ids = self.env['sale.order.line'].search([('product_id','=',rec.id),('order_id.state','in',('draft','sent'))])
            sp_da_bao_gia = sum(line_ids.mapped('product_uom_qty'))
            rec.sp_da_bao_gia = sp_da_bao_gia
            rec.sp_co_the_ban = rec.qty_available - rec.sp_ban_chua_giao - rec.sp_da_bao_gia

    @api.model
    def get_categ_list(self):
        categ_ids = self.env['product.category'].search([]).sorted('display_name', reverse=False).mapped('display_name')
        categ_list = []
        for categ_id in categ_ids:
            categ_list.append(categ_id.replace("/", ">>"))
        return categ_list

    @api.model
    def get_categ_name_search(self,categ_name):
        if categ_name:
            categ_list = categ_name.split('>>')
            parent_id = False
            for categ in categ_list:
                domain = [('name', '=', categ.strip())]
                if not parent_id:
                    categ_id = self.env['product.category'].search(domain)
                    if not categ_id:
                        break
                    parent_id = categ_id
                else:
                    domain.append(('parent_id', '=', parent_id.id))
                    categ_id = self.env['product.category'].search(domain)
                    if not categ_id:
                        break
                    parent_id = categ_id

            if parent_id:
                product_ids = self.env['product.product'].search([('categ_id','=',parent_id.id)])
                return product_ids.ids
            else:
                return []

    @api.model
    def print_product_excel(self,response):
        product_ids = self.env['product.product'].search([])
        output = StringIO.StringIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        worksheet = workbook.add_worksheet('Biến thể sản phẩm')

        body_bold_color = workbook.add_format(
            {'bold': True, 'font_size': '11', 'align': 'left', 'valign': 'vcenter'})
        text_style = workbook.add_format(
            {'bold': False, 'font_size': '11', 'align': 'left', 'valign': 'vcenter'})
        body_bold_color_number = workbook.add_format(
            {'bold': False, 'font_size': '11', 'align': 'left', 'valign': 'vcenter'})
        body_bold_color_number.set_num_format('#,##0')

        worksheet.set_column('A:N', 20)

        summary_header = ['Nhóm sản phẩm', 'Mã biến thể (variant)', 'Tên sản phẩm', 'Thuộc tính 1', 'Thuộc tính 2',
                          'Giá bán', 'Giá vốn',
                          'SL tổng TK', 'SL bán chưa giao', 'SL đã báo giá', 'SL có thể bán']
        row = 0
        [worksheet.write(row, header_cell, unicode(summary_header[header_cell], "utf-8"), body_bold_color) for
         header_cell in range(0, len(summary_header)) if summary_header[header_cell]]

        for product_id in product_ids:
            row += 1
            thuoc_tinh_1 = ''
            thuoc_tinh_2 = ''
            if len(product_id.attribute_value_ids) >= 1:
                thuoc_tinh_1 = product_id.attribute_value_ids[0].display_name
            if len(product_id.attribute_value_ids) >= 2:
                thuoc_tinh_2 = product_id.attribute_value_ids[1].display_name

            worksheet.write(row, 0, product_id.categ_id.display_name.replace("/", ">>"), text_style)
            worksheet.write(row, 1, product_id.default_code if product_id.default_code else '', text_style)
            worksheet.write(row, 2, product_id.name, text_style)
            worksheet.write(row, 3, thuoc_tinh_1, text_style)
            worksheet.write(row, 4, thuoc_tinh_2, text_style)
            worksheet.write(row, 5, product_id.lst_price, body_bold_color_number)
            worksheet.write(row, 6, product_id.standard_price, body_bold_color_number)
            worksheet.write(row, 7, product_id.qty_available, body_bold_color_number)
            worksheet.write(row, 8, product_id.sp_ban_chua_giao, body_bold_color_number)
            worksheet.write(row, 9, product_id.sp_da_bao_gia, body_bold_color_number)
            worksheet.write(row, 10, product_id.sp_co_the_ban, body_bold_color_number)

        workbook.close()
        output.seek(0)
        response.stream.write(output.read())
        output.close()